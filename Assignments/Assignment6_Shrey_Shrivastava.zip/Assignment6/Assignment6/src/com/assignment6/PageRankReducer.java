package com.assignment6;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.io.Text;

public class PageRankReducer extends MapReduceBase implements Reducer<Text, Text, Text, Text> {

	@Override
	public void reduce(Text key, Iterator<Text> values, OutputCollector<Text, Text> collector, Reporter reporter)
			throws IOException {
		// TODO Auto-generated method stub
		String outlinks = "";
		double rank = 0.0;
		ArrayList<Double> differentRanks = new ArrayList<Double>();

		while (values.hasNext()) {
			String value = values.next().toString();
			if (value.startsWith("[")) {
				StringTokenizer tokens = new StringTokenizer(value, "[],");
				tokens.nextToken();
				differentRanks.add(Double.parseDouble(tokens.nextToken()));
			} else {
				outlinks = outlinks + value + ",";
			}

		}

		for (int i = 0; i < differentRanks.size(); i++) {
			rank = rank + differentRanks.get(i);
		}
		rank = Math.round(rank * 100.0) / 100.0;
		String tempKey = key.toString() + "," + rank;
		outlinks = outlinks.substring(0, outlinks.length() - 1);
		collector.collect(new Text(tempKey), new Text(outlinks));
		
	}

}
