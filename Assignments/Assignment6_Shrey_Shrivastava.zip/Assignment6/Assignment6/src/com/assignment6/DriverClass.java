package com.assignment6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class DriverClass extends Configured implements Tool {
	private static final double epsilon=0.001;

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		int res = ToolRunner.run(new Configuration(), new DriverClass(), args);
		System.exit(res);
		
	}

	@Override
	public int run(String[] arg0) throws Exception {
		// TODO Auto-generated method stub
		
		String input;
		String output;
		int iterationCount = 0;
		double difference=Double.MAX_VALUE;
		
		while(difference>epsilon)
		{
			JobConf conf = new JobConf(getConf(), DriverClass.class);

			conf.setMapperClass(PageRankMapper.class);
			conf.setJarByClass(DriverClass.class);

			conf.setMapOutputKeyClass(Text.class);
			conf.setOutputValueClass(Text.class);

			conf.setReducerClass(PageRankReducer.class);
			if(iterationCount==0)
			{
				input = "Input/Input";

			}
			else
			{
				input="assignment6/Output"+(iterationCount-1);
			}
			output = "assignment6/Output"+iterationCount;

			FileInputFormat.addInputPath(conf, new Path(input));
			FileOutputFormat.setOutputPath(conf, new Path(output));
			JobClient.runJob(conf);
			 difference=calculateDifference(conf, input, output,iterationCount);
			iterationCount++;
		}
		System.out.println(iterationCount);
		return 0;
	}

	public double calculateDifference(JobConf conf, String input, String output,int iterationCount) throws IOException {
		double difference=0.0;
		ArrayList<String> pageNamesList = new ArrayList<String>();
		HashMap<String, ArrayList<Double>> map = new HashMap<String, ArrayList<Double>>();
		FileSystem fs = FileSystem.get(conf);
		if(!(fs.isFile(new Path(input))))
		{
			input=input+"/part-00000";
		}
		BufferedReader inputFileReader = new BufferedReader(new InputStreamReader(fs.open(new Path(input))));
		BufferedReader outFileReader = new BufferedReader(new InputStreamReader(
				fs.open(new Path(output + "/part-00000"))));
		String inputLineReaderString;

		while ((inputLineReaderString = inputFileReader.readLine()) != null) {
			StringTokenizer inputFileTokens = new StringTokenizer(inputLineReaderString);
			String pageAndPageRankArray[] = inputFileTokens.nextToken().split(",");
			pageNamesList.add(pageAndPageRankArray[0]);
			if (map.containsKey(pageAndPageRankArray[0])) {
				map.get(pageAndPageRankArray[0]).add(Double.parseDouble(pageAndPageRankArray[1]));

			} else {
				ArrayList<Double> tempList = new ArrayList<Double>();
				tempList.add(Double.parseDouble(pageAndPageRankArray[1]));

				map.put(pageAndPageRankArray[0], tempList);

			}

		}

		String outputLineReaderString;
		while ((outputLineReaderString = outFileReader.readLine()) != null) {
			StringTokenizer outputFileTokens = new StringTokenizer(outputLineReaderString);

			String pageAndPageRankArray[] = outputFileTokens.nextToken().split(",");
			if (map.containsKey(pageAndPageRankArray[0])) {
				map.get(pageAndPageRankArray[0]).add(Double.parseDouble(pageAndPageRankArray[1]));

			} else {
				ArrayList<Double> tempList = new ArrayList<Double>();
				tempList.add(Double.parseDouble(pageAndPageRankArray[1]));

				map.put(pageAndPageRankArray[0], tempList);

			}

		}

		for (int a = 0; a < pageNamesList.size(); a++) {
			ArrayList<Double> tempList = map.get(pageNamesList.get(a));
			System.out.println("key " + pageNamesList.get(a));
			difference=difference+Math.abs(tempList.get(0)-tempList.get(1));
			difference=Math.round(difference*100.0)/100.0;
		}
		System.out.println(difference);
		return difference;

	}

}
