package com.assignment6;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class PageRankMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {
	public static final double BETA = 0.85;

	@Override
	public void map(LongWritable key, Text value, OutputCollector<Text, Text> collector, Reporter reporter)
			throws IOException {
		// TODO Auto-generated method stub
		StringTokenizer tokens = new StringTokenizer(value.toString().trim());

		String pageAndpageRankArray[] = tokens.nextToken().split(",");
		String page = pageAndpageRankArray[0];
		double pageRank = Double.parseDouble(pageAndpageRankArray[1]);

		String outlinks=tokens.nextToken();
		String outlinksArray[] = outlinks.split(",");
		int numberOfOutLinks = outlinksArray.length;
		for (int i = 0; i < numberOfOutLinks; i++) {
			Text collectorKey=new Text(outlinksArray[i]);
			double tempRank=BETA*(pageRank/numberOfOutLinks);
			Text collectorValue=new Text("[ "+page+","+tempRank+" ]");
			collector.collect(collectorKey, collectorValue);
		}
		collector.collect(new Text(page), new Text(outlinks));
		
	}

}
