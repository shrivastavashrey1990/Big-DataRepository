package com.assignment6;

public enum MyCounter {
UPDATED
}
