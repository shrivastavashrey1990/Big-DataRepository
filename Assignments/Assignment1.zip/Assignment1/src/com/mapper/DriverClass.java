package com.mapper;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class DriverClass extends Configured implements Tool{

	@Override
	public int run(String[] args) throws Exception {
		// TODO Auto-generated method stub
		//Initializing Job Configuration object
		JobConf conf=new JobConf(getConf(),DriverClass.class);
		conf.setJobName("job1");

		//setting mapper and driver classes
		conf.setMapperClass(Map.class);
		conf.setJarByClass(DriverClass.class);
		
		//setting mapoutput key and value class
		conf.setMapOutputKeyClass(Text.class);
		conf.setMapOutputValueClass(Text.class);

		//setting the reducer class
		conf.setReducerClass(ReducerClass.class);

		//specifying the input and output path for first job
		FileInputFormat.addInputPath(conf, new Path("/home/shrivia/eclipse/RandomData.txt"));
		FileOutputFormat.setOutputPath(conf, new Path("/home/shrivia/eclipse/Output/OutputIntermediary.txt"));
		
		//running the first job
		JobClient.runJob(conf);
		
		//initializing the second conf object
		JobConf conf1=new JobConf(getConf(),DriverClass.class);
		conf1.setJobName("job2");
		
		//setting the mapper and drvier classes
		conf1.setMapperClass(Map2.class);
		conf1.setJarByClass(DriverClass.class);
	
		//setting the map output keys and values classes
		conf1.setMapOutputKeyClass(Text.class);
		conf1.setMapOutputValueClass(LongWritable.class);
		
		//setting the partitioner and reducer class
		conf1.setPartitionerClass(BrandPartitioner.class);
		conf1.setReducerClass(ReducerClass2.class);
		
		//setting the number of number of reduce tasks
		conf1.setNumReduceTasks(3);

		//setting the input path and output path
		FileInputFormat.addInputPath(conf1, new Path("/home/shrivia/eclipse/Output/OutputIntermediary.txt"));
		FileOutputFormat.setOutputPath(conf1, new Path("/home/shrivia/eclipse/OutputFinal/OutputFinal.txt"));
		JobClient.runJob(conf1);	
		return 0;
	}

	public static void main(String args[]) throws Exception{
     //data generator
		DataGenerator dg=new DataGenerator();
		dg.dataGenerator();
		int res = ToolRunner.run(new Configuration(), new DriverClass(),args);
		System.exit(res);
	}

}
