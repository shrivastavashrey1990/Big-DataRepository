package com.mapper;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Random;

public class DataGenerator {
	private PrintWriter writer;
	private int userID;
	private String fbBrandId;
	private String timeStamp;
	private Random random;
	public void dataGenerator() throws FileNotFoundException, UnsupportedEncodingException
	{
		random=new Random();
		writer=new PrintWriter("/home/shrivia/eclipse/RandomData.txt","UTF-8");
		for(int noOfLines=0;noOfLines<10;noOfLines++)
		{
			userID=random.nextInt(5-1+1)+4;
			System.out.print(userID+" ");
			
			int id=+random.nextInt(10-1+1)+1;
			fbBrandId="brand"+id;
			System.out.print(fbBrandId+" ");
			
			int ts=random.nextInt(4-1+1)+1;
			timeStamp="ts"+ts;
			System.out.println(timeStamp);
			
			writer.println(userID+" "+fbBrandId+" "+timeStamp);
			
			
		}
		writer.close();
	}

}
