package com.mapper;
import java.io.IOException;
import java.util.Iterator;
import java.util.stream.Collector;

import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.io.*;

public class ReducerClass2 extends MapReduceBase implements Reducer<Text, Text, Text, LongWritable> {

	@Override
	public void reduce(Text key, Iterator<Text> values, OutputCollector<Text, LongWritable> collector, Reporter arg3)
			throws IOException {
		// TODO Auto-generated method stub
		
		//counting the number of brand pairs
		int count=0;
		while(values.hasNext()){
			values.next();
			count=count+1;
		}
		collector.collect(key, new LongWritable(count));


	}

}
