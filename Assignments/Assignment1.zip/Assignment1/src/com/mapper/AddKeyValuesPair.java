package com.mapper;

import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.TreeMap;

public class AddKeyValuesPair {
	TreeMap<String, ArrayList> treeMap=new TreeMap<String,ArrayList>();
	private String b="";
//this class uses TreeMap to sort the brand values on basis of timestamp
	public void addValues(String key,String value)
	{
		ArrayList tempList=null;
		if(treeMap.containsKey(key)){
			tempList=treeMap.get(key);
			if(tempList==null){
				tempList= new ArrayList();
			}
			tempList.add(value);
		}
		else
		{
			tempList=new ArrayList();
			tempList.add(value);
			treeMap.put(key, tempList);
		}

	}

	//this method returns the sorted brand values
	public String getBrandValues(){
		StringTokenizer tokens=new StringTokenizer(treeMap.values().toString(), "[ ]");			

		while(tokens.hasMoreTokens())
		{
			b=b+tokens.nextToken();
		}	
		return b.trim();
	}

}
