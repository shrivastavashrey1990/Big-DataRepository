package com.mapper;


import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.Partitioner;

public class BrandPartitioner implements Partitioner<Text, LongWritable>{
	@Override
	public int getPartition(Text key, LongWritable values, int numOfReduceTask) {
		// TODO Auto-generated method stub
		String tokens[]=key.toString().trim().split(",");
		
		//partitioning on the basis of brand values
		if(numOfReduceTask==0){
			return 0;
		}
		
		int value=Integer.parseInt(tokens[0].substring(5));
		if(value>=1&&value<3)
		{
			return 0;
		}
		
		if(value>=3&&value<5)
		{
			return 1%numOfReduceTask;
		}
		else
		{
			return 2%numOfReduceTask;
		}
		
	}

	@Override
	public void configure(JobConf arg0) {
		// TODO Auto-generated method stub
		
	}

}
