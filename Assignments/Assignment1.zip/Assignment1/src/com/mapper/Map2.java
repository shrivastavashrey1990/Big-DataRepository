package com.mapper;
import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class Map2 extends MapReduceBase implements Mapper<LongWritable, Text, Text, LongWritable> {
	
	private	Text tempText=new Text();
	private String tempString;
	private String[] splitBrand;

	@Override
	public void map(LongWritable key, Text value, OutputCollector<Text, LongWritable> collector, Reporter reporter) throws IOException {
		// TODO Auto-generated method stub
		String line=value.toString();

		StringTokenizer tokens=new StringTokenizer(line);
		
		while(tokens.hasMoreTokens())
		{
			tokens.nextToken();
			String brands=tokens.nextToken();
			splitBrand=brands.trim().split(",");
			
			//pairing the different brands
			for(int i=0;i<splitBrand.length;i++)
			{
				//checking if array has more than one brand
				if(splitBrand.length>1){
					for(int j=i+1;j<splitBrand.length;j++){
						tempString=splitBrand[i]+","+splitBrand[j];
						tempText.set(tempString);
						
						//storing brand pairs as key and 1 as the value
						collector.collect(tempText, new LongWritable(1));
						
					}
				}
				else{
					tempText.set(splitBrand[i]);
					
					//storing brand pairs as key and 1 as the value
					collector.collect(tempText, new LongWritable(1));
					
				}
			}
		}
		
	}
}
