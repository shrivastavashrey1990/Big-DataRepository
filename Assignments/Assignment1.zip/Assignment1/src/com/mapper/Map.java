package com.mapper;
import java.io.IOException;
import java.util.*;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class Map extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text>{
	private Text user=new Text();
	private Text brandAndTimeStamp= new Text();

	@Override
	public void map(LongWritable key, Text value, OutputCollector<Text, Text> collector, Reporter arg3) throws IOException {
		// TODO Auto-generated method stub
		//Converting lines to values
		String line=value.toString();
		
		//splitting the line into tokens
		StringTokenizer tokens= new StringTokenizer(line);
		
	
		while(tokens.hasMoreTokens())
		{
			user.set(tokens.nextToken());
			brandAndTimeStamp.set(tokens.nextToken()+" "+tokens.nextToken());
			
			//Collecting output; taking users as key and value as brands and time stamp ID
			collector.collect(user, brandAndTimeStamp);
		}	
	}
}



