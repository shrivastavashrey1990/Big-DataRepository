package com.assignment4;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.io.Text;

public class Reducer1 extends MapReduceBase implements Reducer<Text, Text, Text, Text> {

	@Override
	public void reduce(Text key, Iterator<Text> values, OutputCollector<Text, Text> collector, Reporter reporter)
			throws IOException {
		// TODO Auto-generated method stub
		ArrayList<String> list = new ArrayList<String>();
		String tempValue = "";
		while (values.hasNext()) {
			list.add(values.next().toString());
		}
		Collections.sort(list);
		for (int a = 0; a < list.size(); a++) {
			tempValue = tempValue + list.get(a) + " ";
		}
		collector.collect(key, new Text(tempValue.trim()));
	}
}
