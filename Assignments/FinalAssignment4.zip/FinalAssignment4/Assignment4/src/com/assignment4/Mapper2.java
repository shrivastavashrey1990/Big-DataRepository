package com.assignment4;

import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class Mapper2 extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {

	@Override
	public void map(LongWritable key, Text value, OutputCollector<Text, Text> collector, Reporter reporter)
			throws IOException {
		// TODO Auto-generated method stub
		ArrayList<String> listOfMovieIDs = new ArrayList<String>();
		ArrayList<String> listOfMovieRatings = new ArrayList<String>();

		StringTokenizer tokens = new StringTokenizer(value.toString().trim());
		tokens.nextToken();
		while (tokens.hasMoreTokens()) {
			StringTokenizer tempTokens = new StringTokenizer(tokens.nextToken(), ",");
			listOfMovieIDs.add(tempTokens.nextToken());
			listOfMovieRatings.add(tempTokens.nextToken());
		}

		for (int a=0;a<listOfMovieIDs.size();a++) {
			for (int b=a+1;b<listOfMovieIDs.size();b++) {
				String tempKey = listOfMovieIDs.get(a) + "," + listOfMovieIDs.get(b);
				String tempValue = listOfMovieRatings.get(a) + "," + listOfMovieRatings.get(b);
				collector.collect(new Text(tempKey), new Text(tempValue));
			}
		}

	}

}
