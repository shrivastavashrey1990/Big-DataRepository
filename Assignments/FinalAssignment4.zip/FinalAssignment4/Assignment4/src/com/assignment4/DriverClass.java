package com.assignment4;



import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class DriverClass extends Configured implements Tool {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		int res = ToolRunner.run(new Configuration(), new DriverClass(),args);
		System.exit(res);

	}

	@Override
	public int run(String[] arg0) throws Exception {
		// TODO Auto-generated method stub
		JobConf conf=new JobConf(getConf(),DriverClass.class);
		conf.setJobName("job1");
		
		conf.setMapperClass(Mapper1.class);
		conf.setJarByClass(DriverClass.class);
		
		conf.setMapOutputKeyClass(Text.class);
		conf.setMapOutputValueClass(Text.class);
		
		conf.setReducerClass(Reducer1.class);
		
		FileInputFormat.addInputPath(conf, new Path("input/SampleInput"));
		FileOutputFormat.setOutputPath(conf, new Path("assignment4/OutputIntermdiary"));
		JobClient.runJob(conf);
		
		JobConf conf1=new JobConf(getConf(),DriverClass.class);
		conf1.setJobName("job2");
		
		conf1.setMapOutputKeyClass(Text.class);
		conf1.setMapOutputValueClass(Text.class);
		
		conf1.setMapperClass(Mapper2.class);
		conf1.setJarByClass(DriverClass.class);
		
		conf1.setReducerClass(Reducer2.class);
		
		FileInputFormat.addInputPath(conf1, new Path("assignment4/OutputIntermdiary"));
		FileOutputFormat.setOutputPath(conf1, new Path("assignment4/FinalOutput"));
		JobClient.runJob(conf1);
		
		return 0;
	}

}
