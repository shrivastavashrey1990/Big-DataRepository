package com.assignment4;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class Mapper1 extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {

	@Override
	public void map(LongWritable key, Text values, OutputCollector<Text, Text> collector, Reporter reporter)
			throws IOException {
		// TODO Auto-generated method stub
		StringTokenizer tokens = new StringTokenizer(values.toString().trim());
		String userID = tokens.nextToken();
		String movieID = tokens.nextToken();
		String rating = tokens.nextToken();
		Text tempKey = new Text(userID);
		Text tempValue = new Text(movieID + "," + rating);
		collector.collect(tempKey, tempValue);

	}

}
