package com.assignment4;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;

public class Reducer2 extends MapReduceBase implements Reducer<Text, Text, Text, Text> {

	@Override
	public void reduce(Text key, Iterator<Text> values, OutputCollector<Text, Text> collector, Reporter reporter)
			throws IOException {
		// TODO Auto-generated method stub
		ArrayList<Double> vector1 = new ArrayList<Double>();
		ArrayList<Double> vector2 = new ArrayList<Double>();
		double dotProduct = 0;
		double magOfVector1 = 0;
		double magOfVector2 = 0;
		double similarity = 0;

		while (values.hasNext()) {
			StringTokenizer tokens = new StringTokenizer(values.next().toString().trim(), ",");
			vector1.add(new Double(tokens.nextToken()));
			vector2.add(new Double(tokens.nextToken()));
		}
		for (int a = 0; a < vector1.size(); a++) {
			dotProduct = dotProduct + (vector1.get(a) * vector2.get(a));
			magOfVector1 = magOfVector1 + (vector1.get(a) * vector1.get(a));
			magOfVector2 = magOfVector2 + (vector2.get(a) * vector2.get(a));
		}
		magOfVector1 = Math.sqrt(magOfVector1);
		magOfVector2 = Math.sqrt(magOfVector2);
		

		similarity = dotProduct / (magOfVector1 * magOfVector2);
		similarity=Math.round(similarity*100.0)/100.0;
		String tempValue = similarity + " ";
		collector.collect(key, new Text(tempValue.trim()));
	}

}
