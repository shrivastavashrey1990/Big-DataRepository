package com.tagger;

import java.io.IOException;

import edu.stanford.nlp.tagger.maxent.MaxentTagger;

public class TaggingClass {
	private String tagged;
	public String tagTweet(String tweet) {
		// TODO Auto-generated method stub
		try {
			MaxentTagger tagger=new MaxentTagger("bidirectional-distsim-wsj-0-18.tagger");
			tagged = tagger.tagString(tweet);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tagged;
	}

}
