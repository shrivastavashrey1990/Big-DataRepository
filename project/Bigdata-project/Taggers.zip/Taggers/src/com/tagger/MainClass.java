package com.tagger;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.StringTokenizer;

public class MainClass {
	private HashMap<String, String> mapOfFirstCombination=new HashMap<String, String>();
	private HashMap<String, String> mapOfSecondCombination=new HashMap<String, String>();
	private HashMap<String, String> mapOfThirdCombination=new HashMap<String,String>();
	private HashMap<String, String> mapOfFourthCombination=new HashMap<String,String>();
	private HashMap<String, String> mapOfFifthCombination=new HashMap<String,String>();
	private static final String fileName="File/AfterPOSTweets";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainClass s=new MainClass();
		s.loadMap();

		TaggingClass tagger=new TaggingClass();
		try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(fileName, true)))) {
			for(String line:Files.readAllLines(Paths.get("InputTweets")))
			{
				line=line.replace("Tweet", "");
				line=line.trim();
				line=tagger.tagTweet(line);
				line=s.detectCombination(line);
				out.println(line);
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Stemmer.triggerStemming(fileName);
	}

	private void loadMap()
	{
		//1st combination
		mapOfFirstCombination.put("JJ,NN", "JJ,NN");
		mapOfFirstCombination.put("JJ,NNS","JJ,NNS");

		//2nd combination
		mapOfSecondCombination.put("RB,JJ", "RB,JJ");
		mapOfSecondCombination.put("RBR,JJ", "RBR,JJ");
		mapOfSecondCombination.put("RBS,JJ", "RBS,JJ");

		//3rd combination
		mapOfThirdCombination.put("JJ,JJ", "JJ,JJ");

		//4th combination
		mapOfFourthCombination.put("NN,JJ", "NN,JJ");
		mapOfFourthCombination.put("NNS,JJ", "NNS,JJ");

		//5th combination
		mapOfFifthCombination.put("RB,VB", "RB,VB");
		mapOfFifthCombination.put("RB,VBD", "RB,VBD");
		mapOfFifthCombination.put("RB,VBN", "RB,VBN");
		mapOfFifthCombination.put("RB,VBG", "RB,VBG");

		mapOfFifthCombination.put("RBR,VB", "RBR,VB");
		mapOfFifthCombination.put("RBR,VBD", "RBR,VBD");
		mapOfFifthCombination.put("RBR,VBN", "RBR,VBN");
		mapOfFifthCombination.put("RBR,VBG", "RBR,VBG");

		mapOfFifthCombination.put("RBS,VB", "RBS,VB");
		mapOfFifthCombination.put("RBS,VBD", "RBS,VBD");
		mapOfFifthCombination.put("RBS,VBN", "RBS,VBN");
		mapOfFifthCombination.put("RBS,VBG", "RBS,VBG");
	}
	private String detectCombination(String tweetWithPosTags)
	{
		 HashSet<String> setOfWords;
		
		ArrayList<String> list=new ArrayList<String>();
		String tempTweet="";
		String array[]=tweetWithPosTags.split(" ");

		for(int i=0;i<array.length;i++)
		{
			int firstIndex=i;
			int secondIndex=i+1;
			int thirdIndex=i+2;

			array[i]=array[i].trim();
			if(i<array.length-1)
			{
				int beginIndex=array[firstIndex].indexOf("/");
				String firstPOStag=array[firstIndex].substring(beginIndex+1);
				String firstWordHalf=array[firstIndex].substring(0,beginIndex);

				int beginIndex2=array[secondIndex].indexOf("/");
				String secondPOSTag=array[secondIndex].substring(beginIndex2+1);
				String secondWordHalf=array[secondIndex].substring(0,beginIndex2);

				String posTagCombinationOfFirstTwoIndexes=firstPOStag+","+secondPOSTag;

				//check if first combination
				if(mapOfFirstCombination.containsKey(posTagCombinationOfFirstTwoIndexes)||mapOfFifthCombination.containsKey(posTagCombinationOfFirstTwoIndexes))
				{
					list.add(firstWordHalf);
					list.add(secondWordHalf);
					/*setOfWords.add(firstWordHalf);
					setOfWords.add(secondWordHalf);	*/				
				}



				if(mapOfSecondCombination.containsKey(posTagCombinationOfFirstTwoIndexes)||mapOfThirdCombination.containsKey(posTagCombinationOfFirstTwoIndexes)||mapOfFourthCombination.containsKey(posTagCombinationOfFirstTwoIndexes))
				{
					if(thirdIndex<array.length-1)
					{
						String thirdWord=array[thirdIndex];
						int beginIndex3=thirdWord.indexOf("/");
						String thirdPOSTag=thirdWord.substring(beginIndex3+1);
						if(!(thirdPOSTag.equalsIgnoreCase("NN")||thirdPOSTag.equalsIgnoreCase("NNS")))
						{
							list.add(firstWordHalf);
							list.add(secondWordHalf);
							/*setOfWords.add(firstWordHalf);
							setOfWords.add(secondWordHalf);*/
						}
					}
				}

				/*System.out.println(firstPOStag+","+secondPOSTag);
				System.out.println(firstWordHalf+","+secondWordHalf);
				System.out.println(array[firstIndex]+","+array[secondIndex]);*/
			}
		}

		setOfWords=new HashSet<String>(list);
		Iterator<String> it=setOfWords.iterator();
		while(it.hasNext())
		{
			tempTweet=tempTweet+" "+it.next();
		}
		tempTweet=tempTweet.trim();
		//System.out.println(tempTweet);
		
		return tempTweet;
	}

}
