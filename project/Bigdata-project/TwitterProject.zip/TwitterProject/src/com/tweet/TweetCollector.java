package com.tweet;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import twitter4j.*;

public class TweetCollector {

	public static ArrayList<String> getTweet(String topic) {
		// TODO Auto-generated method stub
		
		Twitter twitter = new TwitterFactory().getInstance();
		ArrayList<String> tweetList = new ArrayList<String>();

		try {
			Map<String, RateLimitStatus> rateLimitStatus = twitter.getRateLimitStatus("search");
			RateLimitStatus searchTweetsRateLimit = rateLimitStatus.get("/search/tweets");

			System.out.printf("You have %d calls remaining out of %d, Limit resets in %d seconds\n",
					searchTweetsRateLimit.getRemaining(), searchTweetsRateLimit.getLimit(),
					searchTweetsRateLimit.getSecondsUntilReset());

			Query query = new Query(topic);
			query.setCount(100);
			query.setLang("en");
			QueryResult result;

				result = twitter.search(query);
				List<Status> tweets = result.getTweets();
				System.out.println("hi");
				for (Status tweet : tweets) {
					tweetList.add(tweet.getText());
					try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("tweets.txt", true)))) {
						out.println(tweet.getText());
					}catch (IOException e) {
						
					}
				}

			for (int a = 0; a < tweetList.size(); a++) {
				System.out.println(tweetList.get(a));
			}
				System.out.println(tweetList.size());
		} catch (TwitterException te) {
			te.printStackTrace();
			System.out.println("Failed to search tweets: " + te.getMessage());
		}
		return tweetList;
		
	}
}
