package com.tweet.cleaner;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.StringTokenizer;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class RemoveDuplicateMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text>{
HashMap<String, String> map=new HashMap<String, String>();
	@Override
	public void map(LongWritable key, Text values, OutputCollector<Text, Text> collector, Reporter arg3) throws IOException {
		// TODO Auto-generated method stub
	StringTokenizer fileTokens=new StringTokenizer(values.toString());
	fileTokens.nextToken();
	String tweet=fileTokens.nextToken();
		try {
			for(String line:Files.readAllLines(Paths.get("Files/RefinedTweets/part-00000")))
			{
				map.put(line.trim(), line.trim());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
//	if()

}
