package com.tweet.cleaner;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class TweetCleanerMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {
	int count = 1;
	private ArrayList<String> listOfAcronyms = new ArrayList<String>();
	private final String punctuation = " ,.:;\"()?<>!-/%~#$^&*|";// constant
																	// punctuation
																	// to remove
																	// delimeters,
																	// special
																	// characters
																	// and
																	// numbers
																	// from the
																	// data
	HashMap<String, String> stopWordsMap = new HashMap<String, String>();
	HashMap<String, String> acronymsMap = new HashMap<String, String>();
	String positiveEmoticonsArray[] = { ":-)", ":)", ":D", ":o)", ":]", ":3", ":c)", ":>", "=]", "8)", "=)", ":}",
			":^)", ":っ)", ":-D", "8-D", "8D", "x-D", "xD", "X-D", "XD", "=-D", "=D", "=-3", "=3", "B^D", ":-))",
			":'-)", ":')", ":*", ":^*", "( '}{' )", ";-)", ";)", "*-)", "*)", ";-]", ";]", ";D", ";^)", ">:P",
			":-P", ":P", "X-P", "x-p", "xp", "XP", ":-p", ":p", "=p", ":-Þ", ":Þ", ":þ", ":-þ", ":-b", ":b", "d:",
			"O:-)", " 0:-3", "0:3", "0:-)", "0:)", "0;^)", "o/\\o", "^5", ">_>", "^ ^", "<_<", ":-J", ":-&", ":&",
			"\\o/", "*\\0/*", "<3", "😀", "😁", "😂", "😃", "😄", "😅", "😆", "😇", "😈", "😉", "😊", "😋", "😌", "😍",
			"😎", "😗", "😘", "😙", "😚", "😛", "😜", "😝", "😤", "😸", "😹", "😺", "😻","🙂","🙋",	"🙌","🙎"};

	String negativeEmoticonsArray[] = { ">:[", ":-(", ":(", ":-c", ":c", ":-<", ":っC", ":<", ":-[", ":[", ":{", ";(",
			":-||", ":@", ">:(", ":'-(", ":'(", "D:<", "D:", "D8", "D;", "D=", "DX", "v.v", "D-':", ">:O", ":-O", ":O",
			":-o", ":o", "8-0", "O_O", "o-o", "O_o", "o_O", "o_o", "O-O", ">:\\", ">:/", ":-/", ":-.", ":/", ":\\",
			"=/", "=\\", ":L", "=L", ":S", ">.<", ":|", ":-|", "|-O", ":-###..", ":###..", "<:-|", "</3", "😏", "😐",
			"😑", "😒", "😓", "😔", "😕", "😖", "😞", "😟", "😠", "😡", "😢", "😣", "😥", "😦", "😧", "😨", "😩", "😬",
			"😭", "😮", "😰", "😱", "😲", "😳", "😼", "😽", "😾", "😿","🙀","🙁","🙍","T_T"};

	String arrayOfNegations[] = { "no", "not", "none", "noone", "nobody", "nothing", "neither", "nowhere", "never",
			"cannot", "n't", "cant" };

	private String tweet;

	@Override
	public void map(LongWritable key, Text value, OutputCollector<Text, Text> collector, Reporter reporter)
			throws IOException {
		// TODO Auto-generated method stub

		tweet = value.toString().trim();

		readListOfSlangs();
		readStopWords();

		tweet = replaceURLsatTheRateandHashTagSymbol(tweet);
		tweet = replaceEmoticons(tweet);
		tweet = replaceAcronyms(tweet);
		tweet = replaceNegations(tweet);
		tweet = removeStopWords(tweet);
		collector.collect(new Text("Tweet"), new Text(tweet));

	}

	private void readListOfSlangs() {
		try {
			for (String line : Files.readAllLines(Paths.get("Files/ListOfSlang"))) {
				StringTokenizer lineTokens = new StringTokenizer(line, "-");
				String acronym = lineTokens.nextToken().trim();
				String acronymMeaning = lineTokens.nextToken().trim();
				acronymMeaning = acronymMeaning.trim();
				listOfAcronyms.add(acronym);
				acronymsMap.put(acronym, acronymMeaning);
				// System.out.println(acronym+" : "+acronymMeaning);

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void readStopWords() {
		try {
			for (String line : Files.readAllLines(Paths.get("Files/stopWords"))) {
				stopWordsMap.put(line.trim(), line.trim());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String replaceURLsatTheRateandHashTagSymbol(String tweet) {
		tweet = tweet.replaceAll("\\s*RT\\s*@\\w+:\\s*", "");
		tweet = tweet.replaceAll("\\s*@\\w*", "");
		tweet = tweet.replace("#", "");
		tweet = tweet.replaceAll("https?:[^\\s]*", "");
		return tweet;
	}

	private String replaceEmoticons(String tweet) {
		for (int i = 0; i < positiveEmoticonsArray.length; i++) {

			tweet = tweet.replace(positiveEmoticonsArray[i], " positive ");

		}
		for (int j = 0; j < negativeEmoticonsArray.length; j++) {

			tweet = tweet.replace(negativeEmoticonsArray[j], " negative ");

		}
		return tweet;
	}

	private String replaceAcronyms(String tweet) {
		/*
		 * for(int a=0;a<listOfAcronyms.size();a++) {
		 * tweet=tweet.replace(listOfAcronyms.get(a),
		 * acronymsMap.get(listOfAcronyms.get(a))); }
		 */
		String tempTweet = "";
		StringTokenizer tweetTokens = new StringTokenizer(tweet, punctuation);
		while (tweetTokens.hasMoreTokens()) {
			String temporayToken = tweetTokens.nextToken().toLowerCase();
			if (acronymsMap.containsKey(temporayToken)) {
				temporayToken = acronymsMap.get(temporayToken);
			}
			tempTweet = tempTweet + " " + temporayToken;
		}

		tweet = tempTweet.trim().toLowerCase();
		return tweet;
	}

	private String replaceNegations(String tweet) {
		if (tweet.contains("n't")) {

			int pos = tweet.indexOf("n't");
			String firstPart = tweet.substring(0, pos);
			String secondPart = tweet.substring(pos, tweet.length());
			tweet = firstPart + " " + secondPart;

		}
		tweet = tweet.replace("n't", "NOT");

		StringTokenizer tempTokens = new StringTokenizer(tweet);
		String tempTweet = "";
		while (tempTokens.hasMoreTokens()) {
			String temporaryToken = tempTokens.nextToken();
			for (int i = 0; i < arrayOfNegations.length; i++) {
				if (temporaryToken.equalsIgnoreCase(arrayOfNegations[i])) {
					temporaryToken = "NOT";
					break;
				}

			}
			tempTweet = tempTweet + " " + temporaryToken;
		}
		tweet = tempTweet.trim();

		return tweet;
	}

	private String removeStopWords(String tweet) {
		StringTokenizer tweetTokens = new StringTokenizer(tweet, punctuation);
		String finalTweet = "";
		while (tweetTokens.hasMoreTokens()) {
			String tempToken = tweetTokens.nextToken();
			if (!(stopWordsMap.containsKey(tempToken.toLowerCase())) || tempToken.equals("NOT")) {
				if (tempToken.equalsIgnoreCase("NOT")) {
					finalTweet = finalTweet + " " + tempToken;
				} else {
					finalTweet = finalTweet + " " + tempToken.toLowerCase();
				}

			}
		}
		finalTweet = finalTweet.trim();
		return finalTweet;
	}
	
	 

}
