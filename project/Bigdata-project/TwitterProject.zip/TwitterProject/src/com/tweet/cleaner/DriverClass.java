package com.tweet.cleaner;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;






public class DriverClass extends Configured implements Tool {
	private String inputPath="Files/InputTweetsWithSentiments";
	private String outputPath="RefinedTweets";
	String arrayOfNegations[]={"no",
			"not",
			"none",
			"noone",
			"Nobody",
			"nothing",
			"neither",
			"nowhere",
			"never",
			"cannot",
			"n't",
	"cant"};

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		int res = ToolRunner.run(new Configuration(), new DriverClass(),args);
		System.exit(res);
	}

	@Override
	public int run(String[] arg0) throws Exception {
		// TODO Auto-generated method stub
		JobConf conf=new JobConf(getConf(),DriverClass.class);
		conf.setJobName("job1");
		
		conf.setMapperClass(TweetCleanerMapper.class);
		conf.setJarByClass(DriverClass.class);
		
		conf.setMapOutputKeyClass(Text.class);
		conf.setMapOutputValueClass(Text.class);
		conf.setReducerClass(TweetCleanerReducer.class);
		
		FileInputFormat.addInputPath(conf, new Path(inputPath));
		FileOutputFormat.setOutputPath(conf, new Path(outputPath));
		JobClient.runJob(conf);
		return 0;
	}
	
	

}
