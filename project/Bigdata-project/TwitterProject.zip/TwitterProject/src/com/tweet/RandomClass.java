package com.tweet;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class RandomClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String topic = "iphone6";
		ArrayList<String> tweets = TweetCollector.getTweet(topic);
		
		for(String tweet : tweets) {
		//	System.out.println(tweet + " : " + SentimentCalculator.findSentiment(tweet));
			try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("myfile.txt", true)))) {
				out.println(tweet);
			}catch (IOException e) {
				//exception handling left as an exercise for the reader
			}
		}
	}

}
