package com.extractTweets;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ExtractTweets {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("Output/InputTweets", true)))) {
			for(String line:Files.readAllLines(Paths.get("part-00000")))
			{
				int length=line.length();
				line=line.substring(0,length-1).trim();
				out.println(line);
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
