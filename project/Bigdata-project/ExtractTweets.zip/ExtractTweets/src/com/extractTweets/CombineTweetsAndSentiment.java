package com.extractTweets;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class CombineTweetsAndSentiment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> list1=new ArrayList<String>();
		ArrayList<String> list2=new ArrayList<String>();
		
		try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("Output/FinalOutput", true)))){
			for(String line:Files.readAllLines(Paths.get("part-00000")))
			{
				int length=line.length();
				line=line.substring(length-1).trim();
				list1.add(line);
				
			}
			
			for(String line:Files.readAllLines(Paths.get("TweetsAfterStemming")))
			{
				
				line=line.trim();
				list2.add(line);
				
			}
			
			for(int i=0;i<list2.size();i++)
			{
				String a="";
				if(!(list2.get(i).isEmpty()))
				{
					a=list1.get(i)+"\t"+list2.get(i);
					out.println(a);
				}
				
			}
			
			
			//System.out.println(count);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
